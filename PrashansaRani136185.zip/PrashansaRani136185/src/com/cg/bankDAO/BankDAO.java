package com.cg.bankDAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cg.bankBean.AccountBean;
import com.cg.bankBean.TransactionBean;
import com.cg.bankException.BankException;
import com.cg.bankUtility.DBUtil;

public class BankDAO implements IBankDAO {
	public BankDAO() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public ArrayList<AccountBean> retrieveAccountDetails(String customerName)
			throws BankException {
		ArrayList<AccountBean> list = new ArrayList<AccountBean>();
		String sql = "select * from account_details where customer_name = ?";	
		Connection connection = null;
		PreparedStatement preparedStatement = null;
		try {
			connection = DBUtil.createConnection();
			preparedStatement = connection.prepareStatement(sql);
			preparedStatement.setString(1, customerName);
			ResultSet rs = preparedStatement.executeQuery();
			boolean f = true;
			while(rs.next()){
				f = false;
				AccountBean ab = new AccountBean();
				ab.setAccountNumber(rs.getString(1));
				ab.setCustomerName(rs.getString(2));
				ab.setAccountType(rs.getString(3));
				ab.setAccountLocation(rs.getString(4));
				ab.setBalance(rs.getFloat(5));

				list.add(ab);
			}
			
			if(f){
				throw new BankException("Name Not Found Exception");
			}
		} catch (SQLException e) {
			throw new BankException("Name Not Found Exception");
		}
		return list;
	}

	@Override
	public int insertTransactionDetails(TransactionBean transactionBean)
			throws BankException {
		String sql = "insert into transaction_details values(transaction_id_seq.nextval,?,?,sysdate,?)";
		Connection connection = null;
		PreparedStatement ps = null;
		int status = 0;
		try {
			connection = DBUtil.createConnection();
			ps = connection.prepareStatement(sql);
			ps.setString(1, transactionBean.getTransactionDescription());
			ps.setObject(2, transactionBean.getTransactionAmount());
			ps.setString(3, transactionBean.getAccountNumber());
			
			status = ps.executeUpdate();
			if(status == 0){
				throw new BankException("Records are not inserted");	
			}
		} catch (SQLException e) {
			
			throw new BankException("Transaction Details are Not Updated");
		}
		
		return status;
	}
	
}