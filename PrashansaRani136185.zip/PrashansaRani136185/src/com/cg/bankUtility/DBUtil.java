package com.cg.bankUtility;

import java.sql.Connection;
import java.sql.SQLException;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;


public class DBUtil {
	private static Connection conn;
	
	public static Connection createConnection(){
		try {
			InitialContext context= new InitialContext();
			DataSource ds= (DataSource) context.lookup("java:/jdbc/OracleDS");
    		 conn= ds.getConnection();
		} catch (NamingException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return conn;
	}

}
