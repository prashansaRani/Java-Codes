package com.cg.bankBean;

import java.util.Date;

public class TransactionBean {

	private int transactionId;
	private String transactionDescription;
	private float transactionAmount;
	private Date transactionDate;
	private String accountNumber;
	

	public TransactionBean() {
		// TODO Auto-generated constructor stub
	}


	public int getTransactionId() {
		return transactionId;
	}


	public void setTransactionId(int transactionId) {
		this.transactionId = transactionId;
	}


	public String getTransactionDescription() {
		return transactionDescription;
	}


	public void setTransactionDescription(String transactionDescription) {
		this.transactionDescription = transactionDescription;
	}


	public float getTransactionAmount() {
		return transactionAmount;
	}


	public void setTransactionAmount(float transactionAmount) {
		this.transactionAmount = transactionAmount;
	}


	public Date getTransactionDate() {
		return transactionDate;
	}


	public void setTransactionDate(Date transactionDate) {
		this.transactionDate = transactionDate;
	}


	public String getAccountNumber() {
		return accountNumber;
	}


	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}


	@Override
	public String toString() {
		return "TransactionBean [transactionId=" + transactionId
				+ ", transactionDescription=" + transactionDescription
				+ ", transactionAmount=" + transactionAmount
				+ ", transactionDate=" + transactionDate + ", accountNumber="
				+ accountNumber + "]";
	}
	
}
