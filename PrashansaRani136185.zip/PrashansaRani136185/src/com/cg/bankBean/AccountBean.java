package com.cg.bankBean;

public class AccountBean {
	private String accountNumber;
	private String customerName;
	private String accountType;
	private String accountLocation;
	private float balance;
	
	public AccountBean() {
		// TODO Auto-generated constructor stub
	}


	public String getAccountNumber() {
		return accountNumber;
	}


	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public String getAccountType() {
		return accountType;
	}


	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}


	public String getAccountLocation() {
		return accountLocation;
	}


	public void setAccountLocation(String accountLocation) {
		this.accountLocation = accountLocation;
	}


	public float getBalance() {
		return balance;
	}


	public void setBalance(float balance) {
		this.balance = balance;
	}


	@Override
	public String toString() {
		return "AccountBean [accountNumber=" + accountNumber
				+ ", customerName=" + customerName + ", accountType="
				+ accountType + ", accountLocation=" + accountLocation
				+ ", balance=" + balance + "]";
	}
	

	

}
