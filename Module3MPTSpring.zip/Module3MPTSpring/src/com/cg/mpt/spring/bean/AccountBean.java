package com.cg.mpt.spring.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Account_Details")
public class AccountBean {

	@Id
	@Column(name = "Account_Number")
	String accNum;
	@Column(name = "Customer_Name")
	String custName;
	@Column(name = "Account_Type")
	String accType;
	@Column(name = "Account_Location")
	String accLocation;
	@Column(name = "Balance")
	double balance;
	
	public AccountBean() {
		
	}

	public AccountBean(String accNum, String custName, String accType,
			String accLocation, double balance) {
		
		this.accNum = accNum;
		this.custName = custName;
		this.accType = accType;
		this.accLocation = accLocation;
		this.balance = balance;
	}

	public String getAccNum() {
		return accNum;
	}

	public void setAccNum(String accNum) {
		this.accNum = accNum;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	public String getAccLocation() {
		return accLocation;
	}

	public void setAccLocation(String accLocation) {
		this.accLocation = accLocation;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "AccountBean [accNum=" + accNum + ", custName=" + custName
				+ ", accType=" + accType + ", accLocation=" + accLocation
				+ ", balance=" + balance + "]";
	}
}