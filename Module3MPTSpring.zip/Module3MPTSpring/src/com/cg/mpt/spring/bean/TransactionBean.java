package com.cg.mpt.spring.bean;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity(name="Transaction_Details")
public class TransactionBean {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name = "Transaction_Id")
	int transId;
	@Column(name = "Transaction_Description")
	String transDesc;
	@Column(name = "Transaction_Amount")
	double transAmt;
	@Column(name = "Transaction_Date")
	Date transDate;
	@Column(name = "Account_Number")
	String accNum;
	public TransactionBean(int transId, String transDesc, double transAmt,
			Date transDate, String accNum) {
		
		this.transId = transId;
		this.transDesc = transDesc;
		this.transAmt = transAmt;
		this.transDate = transDate;
		this.accNum = accNum;
	}
	public TransactionBean() {
		
	}
	public int getTransId() {
		return transId;
	}
	public void setTransId(int transId) {
		this.transId = transId;
	}
	public String getTransDesc() {
		return transDesc;
	}
	public void setTransDesc(String transDesc) {
		this.transDesc = transDesc;
	}
	public double getTransAmt() {
		return transAmt;
	}
	public void setTransAmt(double transAmt) {
		this.transAmt = transAmt;
	}
	public Date getTransDate() {
		return transDate;
	}
	public void setTransDate(Date date) {
		this.transDate = date;
	}
	public String getAccNum() {
		return accNum;
	}
	public void setAccNum(String accNum) {
		this.accNum = accNum;
	}
}