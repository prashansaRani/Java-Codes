package com.cg.mpt.spring.controller;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.mpt.spring.bean.AccountBean;
import com.cg.mpt.spring.bean.TransactionBean;
import com.cg.mpt.spring.dao.BankDaoImpl;
import com.cg.mpt.spring.dao.IBankDao;

@Controller
public class BankController {
	  @Autowired
      IBankDao dao = new BankDaoImpl();
	  
 
            
      @RequestMapping(value="/accinfo.htm",method=RequestMethod.POST)
      public String accountInfo(@RequestParam("custName") String custName,Model map){
    	  String redirect,msg = null;
    	  List<AccountBean> accList = new ArrayList<AccountBean>();
    	  accList = dao.getAccountDetails(custName);
    	  map.addAttribute("accList",accList);
    	  redirect = "accountinfo";
    	  if(!accList.contains(null)){
    		  redirect = "accountinfo";
    	  }
    	  else{
    		  redirect = "login";
    		  msg = "Customer Not found. Try Again";
    		  map.addAttribute("message", msg);
    	  }
    	  return redirect;
      }
      @RequestMapping(value="/debit")
      public String debitAmount(@RequestParam("accNum") String accNum, Model map){ 
    	  
    	  map.addAttribute("accNum", accNum);
    	  return "debit";
      }
      @RequestMapping(value="/success.htm",method=RequestMethod.POST)
      public String debitAmzount(@RequestParam("amt") double amt,
    		  @RequestParam("accNum") String accNum,Model map){
    	  
    	  map.addAttribute("amt", amt);
    	  map.addAttribute("accNum", accNum);
      	  TransactionBean transactionBean = new TransactionBean();
    	  transactionBean.setTransAmt(amt);
    	  
    	  Date date = Date.valueOf(LocalDate.now());
    	  
    	  transactionBean.setTransDate(date);
    	  transactionBean.setTransDesc("DEBIT AMT");
    	  transactionBean.setAccNum(accNum);
    	  dao.insertTransactionDetails(transactionBean);
    	  /*if(amt>0){
    		  msg = "debited amount is "+amt+"from account number ";
    		  redirect = "success";
    	  }
    	  else{
    		  msg = "Enter amount greater than zero";
    		  redirect = "debit";
    		  map.addAttribute("message", msg);
    	  }*/
    	  return "success";
      }
}
