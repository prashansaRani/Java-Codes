package com.cg.mpt.spring.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.cg.mpt.spring.bean.AccountBean;
import com.cg.mpt.spring.bean.TransactionBean;

@Component
@Repository
@Transactional
public class BankDaoImpl implements IBankDao {

	@PersistenceContext
	EntityManager entityManager;
	public BankDaoImpl() {
		// TODO Auto-generated constructor stub
	}

	
	@Override
	public List<AccountBean> getAccountDetails(String custName) {
		String qry = "SELECT account FROM AccountBean account WHERE account.custName =:custName";
		TypedQuery<AccountBean> query = entityManager.createQuery(qry, AccountBean.class);
		query.setParameter("custName", custName);
		List<AccountBean> accList = query.getResultList();
		return accList;
	}

	@Override
	public TransactionBean insertTransactionDetails(
			TransactionBean transactionBean) {
		entityManager.persist(transactionBean);
		return transactionBean;
	}
}