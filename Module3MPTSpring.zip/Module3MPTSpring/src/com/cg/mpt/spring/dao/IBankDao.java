package com.cg.mpt.spring.dao;

import java.util.List;

import com.cg.mpt.spring.bean.AccountBean;
import com.cg.mpt.spring.bean.TransactionBean;

public interface IBankDao {

	public List<AccountBean> getAccountDetails(String custName) ;
	public TransactionBean insertTransactionDetails(TransactionBean transactionBean) ;
}