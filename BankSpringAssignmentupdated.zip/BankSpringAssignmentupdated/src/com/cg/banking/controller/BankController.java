package com.cg.banking.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.banking.entities.AccountBean;
import com.cg.banking.service.IBankService;


@Controller
public class BankController {

	@Autowired
	IBankService ibs;


	@RequestMapping("/getDetails.htm")
	public String retrieve(@RequestParam("customerName") String customerName,Model model)
	{
		//System.out.println("in controller");
		List<AccountBean> accountList = ibs.getAccountDetails(customerName);
		model.addAttribute("accountList", accountList);
		//System.out.println("accountList"+accountList);
		model.addAttribute("message", "Summary of accounts held by "+customerName);
		return "AccountInfo";	
	}

	@RequestMapping("/debit.htm")
	public String debitFun(@RequestParam("accountNumber") String accountNumber,Model model)
	{
		model.addAttribute("accountNumber", accountNumber);
		model.addAttribute("message", "Debit the amount from "+accountNumber+" Account");
		return "debitAmount";
	}

	@RequestMapping("/transaction.htm")
	public String update(@RequestParam("balance") String balance,@RequestParam("accountNumber") String accountNumber,Model model)
	{
		AccountBean ab = new AccountBean();
		//String accountNumber = 
		//ab.setAccountNumber("1234556678");
		//model.addAttribute("accountNumber", ab.getAccountNumber());
		model.addAttribute("accountNumber",accountNumber);
		//System.out.println("account number"+ab.getAccountNumber());
		model.addAttribute("message", "debit transaction of amount "+balance+" has been successfully done on account number ");
		return "transactionSuccess";
	}


}
