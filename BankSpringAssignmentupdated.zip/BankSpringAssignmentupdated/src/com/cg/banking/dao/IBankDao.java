package com.cg.banking.dao;

import java.util.List;

import com.cg.banking.entities.AccountBean;

public interface IBankDao {

	List<AccountBean> getAccountDetails(String customerName);

}
