package com.cg.banking.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.banking.entities.AccountBean;


@Repository
@Transactional
@Component
public class BankDao implements IBankDao{

	@PersistenceContext
	private EntityManager entityManager;

	@Override
	public List<AccountBean> getAccountDetails(String customerName)
	{
		System.out.println("in dao");
		TypedQuery<AccountBean> query = entityManager.createQuery("select a from AccountBean a where a.customerName=:custName", AccountBean.class);
		query.setParameter("custName", customerName);
		/*TypedQuery<AccountBean> query = entityManager.createQuery("select a from AccountBean a where a.customerName="+customerName, AccountBean.class);
		query.setParameter("custName", customerName);*/
		return query.getResultList();
	}

}
