package com.cg.banking.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.banking.dao.IBankDao;
import com.cg.banking.entities.AccountBean;

@Service
public class BankService implements IBankService{

	@Autowired
	IBankDao ibd;


	@Override
	public List<AccountBean> getAccountDetails(String customerName)
	{
		System.out.println("in service");
		return ibd.getAccountDetails(customerName);
	}

}
