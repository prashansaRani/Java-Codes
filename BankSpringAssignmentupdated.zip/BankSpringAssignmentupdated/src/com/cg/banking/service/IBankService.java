package com.cg.banking.service;

import java.util.List;

import com.cg.banking.entities.AccountBean;

public interface IBankService {

	List<AccountBean> getAccountDetails(String customerName);

}
