package com.cg.service;

public class AirlineServiceImpl {

	public AirlineServiceImpl() {
		
	}

}
