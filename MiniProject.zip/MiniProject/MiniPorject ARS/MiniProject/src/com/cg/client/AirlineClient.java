package com.cg.client;

public class AirlineClient {

	public static void main(String[] args) {
		

	}

}
