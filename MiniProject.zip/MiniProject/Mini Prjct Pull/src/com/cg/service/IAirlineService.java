package com.cg.service;

import com.cg.exception.AirlineException;

public interface IAirlineService {

	void flightOccupancyDetails(String classType, String flightNo) throws AirlineException;

}
