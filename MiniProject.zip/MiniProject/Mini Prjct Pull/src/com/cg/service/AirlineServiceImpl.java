package com.cg.service;

import com.cg.dao.AirlineDAOImpl;
import com.cg.dao.IAirlineDAO;
import com.cg.exception.AirlineException;

public class AirlineServiceImpl implements IAirlineService {

	IAirlineDAO iad = null;
	public AirlineServiceImpl() {
		
		iad = new AirlineDAOImpl();
	}

	@Override
	public void flightOccupancyDetails(String classType, String flightNo) throws AirlineException {
		// TODO Auto-generated method stub
		iad.flightOccupancyDetails(classType,flightNo);
	}
	

}
