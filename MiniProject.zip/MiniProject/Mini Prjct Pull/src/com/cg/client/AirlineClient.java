package com.cg.client;

import com.cg.exception.AirlineException;
import com.cg.service.AirlineServiceImpl;
import com.cg.service.IAirlineService;

public class AirlineClient {

	private static IAirlineService ias=new AirlineServiceImpl();
	/*public AirlineClient()
	{
		ias = ;
	}*/
	public static void main(String args[]) throws AirlineException
	{
		String classType="first";
		String flightNo="1001";
		ias.flightOccupancyDetails(classType,flightNo);
	}

}
