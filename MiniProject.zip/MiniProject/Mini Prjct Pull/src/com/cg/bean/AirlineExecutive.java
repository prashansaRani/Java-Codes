package com.cg.bean;


public class AirlineExecutive extends User{

	public AirlineExecutive() {
		super();
	}

	public AirlineExecutive(String username, String password) {
		super(username, password);
	}
	
}
