package com.cg.bean;


public class Administrator extends User{

	public Administrator() {
		super();
	}

	public Administrator(String username, String password) {
		super(username, password);
	}
	
	public void updateFlightSchedule(){
		
	}
}
