package com.cg.ars.utility;

public class MyUtil {
	public static double calculatefare(int noOfPassengers, double baseFare) {
		return (noOfPassengers * baseFare);
	}
}
