package com.cg.controller;

import javax.validation.Valid;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.dto.AdminDTO;
import com.cg.dto.TraineeDTO;
import com.cg.service.ITraineeService;
import com.cg.service.TraineeService;


@Controller
@RequestMapping(value="trainee")
public class TraineeController {
	
	ITraineeService traineeService=new TraineeService();
	
	@RequestMapping(value="/login")
	public String loginMenu(Model model)
	{
		System.out.println("In loginMenu() method");
		model.addAttribute("adminDTO",new AdminDTO());
		//ModelAndView("Home","accountsDTO",new AccountsDTO());
		return "LoginMenu";
	}
	
	@RequestMapping(value="/checkAdmin")
	public String checkAdmin(@ModelAttribute("adminDTO")
	@Valid AdminDTO adminDTO,
	BindingResult result,Model model)
	{
		System.out.println("In checkAdmin() method");
		
		if(result.hasErrors())
			return "LoginMenu";
		//ModelAndView("Home","accountsDTO",new AccountsDTO());
		
		
		if(adminDTO.getUsername().equals("pratik")&&adminDTO.getPassword().equals("zyrus"))
			return "addTrainee.obj";
		else
			return "Failure";
	}
	
	@RequestMapping(value="/addTrainee")
	public String addTrainee(Model model)
	{
		System.out.println("In addTrainee() method");
		model.addAttribute("traineeDTO",new TraineeDTO());
		return "addTrainee";
		
	}
	
	

}
