/**
 * 
 */
package com.cg.service;

import com.cg.dto.AdminDTO;

/**
 * @author pratiksa
 *
 */
public interface ITraineeService {

	boolean checkAdmin(AdminDTO adminDTO);

}
