package com.cg.banking.dao;

public class BankDao {

}
