package com.cg.banking.dao;

public interface IBankDao {

}
