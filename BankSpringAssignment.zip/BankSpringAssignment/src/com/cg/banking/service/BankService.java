package com.cg.banking.service;

public class BankService {

}
