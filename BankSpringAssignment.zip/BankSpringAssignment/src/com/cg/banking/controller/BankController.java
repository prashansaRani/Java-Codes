package com.cg.banking.controller;

import java.awt.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.banking.entities.AccountBean;
import com.cg.banking.service.IBankService;


@Controller
public class BankController {
	@Autowired
	IBankService ibs;
	
	
	@RequestMapping("/getDetails.htm")
	public String Retrieve(@RequestParam("customerName") String customerName,Model model)
	{
		List<AccountBean> accountList = ibs.getAccountDetails(customerName);
		model.addAttribute("accountList", accountList);
		return "AccountInfo";
		
	}
	

}
