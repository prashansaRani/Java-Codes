package com.cg.bankService;

import java.util.ArrayList;

import com.cg.bankBean.AccountBean;
import com.cg.bankBean.TransactionBean;
import com.cg.bankDAO.BankDAO;
import com.cg.bankException.BankException;

public class BankService implements IBankService {

	private BankDAO bankingDAOImpl = null;
	public BankService() {
		bankingDAOImpl = new BankDAO();
	}

	@Override
	public ArrayList<AccountBean> retrieveAccountDetails(String customerName) throws BankException {
		return bankingDAOImpl.retrieveAccountDetails(customerName);
	}

	@Override
	public int insertTransactionDetails(TransactionBean tb) throws BankException {
		return bankingDAOImpl.insertTransactionDetails(tb);
	}

}
