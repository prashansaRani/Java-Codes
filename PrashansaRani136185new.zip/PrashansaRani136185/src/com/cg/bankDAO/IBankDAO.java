package com.cg.bankDAO;

import java.util.ArrayList;

import com.cg.bankBean.AccountBean;
import com.cg.bankBean.TransactionBean;
import com.cg.bankException.BankException;

public interface IBankDAO {
	public ArrayList<AccountBean> retrieveAccountDetails(String customerName) throws BankException;	
	public int insertTransactionDetails(TransactionBean transactionBean) throws BankException;
}
