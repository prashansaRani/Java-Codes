package com.cg.bankController;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.bankBean.AccountBean;
import com.cg.bankBean.TransactionBean;
import com.cg.bankException.BankException;
import com.cg.bankService.BankService;
import com.cg.bankService.IBankService;

@WebServlet("/BankController")
public class BankController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	IBankService ibs = null;
	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public BankController() {
		super();
		ibs = new BankService();
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String action= request.getParameter("action");
		//System.out.println(action);
		RequestDispatcher rd=null;

		switch (action) {
		case "1":
			ArrayList<AccountBean> accountList = new ArrayList<AccountBean>();
			try {
				String customerName = request.getParameter("customerName");
				accountList = ibs.retrieveAccountDetails(customerName);
				System.out.println("..."+accountList.size());
				request.setAttribute("accountlist", accountList);
				request.setAttribute("customerName",customerName);
				rd = request.getRequestDispatcher("AccountInfo.jsp");
				rd.forward(request, response);
			} catch (BankException be) {
				request.setAttribute("Error", be.getMessage());
				rd = request.getRequestDispatcher("CustomerError.jsp");
				rd.forward(request, response);
			}
			break;

		case "2":
			String accountNo = request.getParameter("no");
			request.setAttribute("account_no", accountNo);
			RequestDispatcher requestDispatcher = request.getRequestDispatcher("DebitAmount.jsp");
			requestDispatcher.forward(request, response);
			break;
			
		case "3":
			TransactionBean tb = new TransactionBean();
			tb.setAccountNumber(request.getParameter("no"));
			tb.setTransactionAmount(Integer.parseInt(request.getParameter("amount")));
			tb.setTransactionDescription("ATM Debit");

			try {
				ibs.insertTransactionDetails(tb);
				request.setAttribute("amount", tb.getTransactionAmount());
				request.setAttribute("accountNo", tb.getAccountNumber());
				rd = request.getRequestDispatcher("TransactionSuccess.jsp");
				rd.forward(request, response);
			} catch (BankException be) {
				request.setAttribute("Error", be.getMessage());
				rd = request.getRequestDispatcher("CustomerError.jsp");
				rd.forward(request, response);
			}
			break;
		default:
			break;
		}
	}

}
