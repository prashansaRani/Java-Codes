package com.capgemini.dto;

import java.io.Serializable;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name = "ACCOUNT_DETAILS")
public class AccountsDTO implements Serializable 
{
	/*public Set<TransactionDTO> getTransactionDTOList() {
		return transactionDTOList;
	}
	public void setTransactionDTOList(Set<TransactionDTO> transactionDTOList) {
		this.transactionDTOList = transactionDTOList;
	}*/
	@Id
	@Column(name="account_number")
	private String accountNum;
	
	
	@NotEmpty(message="Name is mandatory")
	@Pattern(regexp="^[A-Z][A-Za-z\t]{,14}$",message="Enter Valid Pattern")
	@Column(name="customer_name")
	private String custName;
	
	@Column(name="account_type")
	private String accountType;
	
	@Column(name="account_location")
	private String accountLoc;
	
	@Column(name="balance")
	private double balance;
	
	//@OneToMany(mappedBy="accountsDTO",cascade=CascadeType.ALL)
	//@JoinColumn(name="account_number")
	//private Set<TransactionDTO>transactionDTOList =new HashSet();
	
	public String getAccountNum() {
		return accountNum;
	}
	public void setAccountNum(String accountNum) {
		this.accountNum = accountNum;
	}
	public String getCustName() {
		return custName;
	}
	public void setCustName(String custName) {
		this.custName = custName;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getAccountLoc() {
		return accountLoc;
	}
	public void setAccountLoc(String accountLoc) {
		this.accountLoc = accountLoc;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public AccountsDTO() {
		super();
	}
	

}
