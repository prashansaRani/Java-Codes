package com.capgemini.controller;

import java.sql.Date;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.capgemini.dao.AccountsRepository;
import com.capgemini.dto.AccountsDTO;
import com.capgemini.dto.TransactionDTO;


@Scope("session")
@Controller
@RequestMapping(value="bank")
public class BankController {
	
	//@Autowired
	AccountsRepository accountsRepository=new AccountsRepository();
	
	
	
	@RequestMapping(value="/customerMenu")
	public String customerMenu(Model model)
	{
		System.out.println("In checkCustomer() method");
		model.addAttribute("accountsDTO",new AccountsDTO());
		//ModelAndView("Home","accountsDTO",new AccountsDTO());
		return "Home";
	}
	
	@RequestMapping(value="/checkCustomer")
	public String checkCustomer(@ModelAttribute("accountsDTO")
	@Valid AccountsDTO accountsDTO,
			BindingResult result,Model model)
	{
		if(result.hasErrors())
			return "Home";
		
		List<AccountsDTO> accountDetailsList=new ArrayList<AccountsDTO>();
		accountDetailsList= accountsRepository.getAccountDetails(accountsDTO);
		if(accountDetailsList.size()!=0)
		{
			
			model.addAttribute("accountDetailsList",accountDetailsList);
			model.addAttribute("custName",accountsDTO.getCustName());
			return "AccountInfo";
		}
		else
		{
			model.addAttribute("custName",accountsDTO.getCustName());
			return "ErrorAccountInfo";
		}
	}
	
	@RequestMapping(value="/DebitAmountController")
	public String debitBalance(@RequestParam("balance") double balance,
			@RequestParam("accountNum") String accountNum,
			Model model)
	{
		System.out.println("In debitBalance() method");
		model.addAttribute("balance",balance);
		model.addAttribute("accountNum",accountNum);
		return "DebitAmount";
	}
	@RequestMapping(value="/UpdateTransaction")
	public String insertTransactionDetails(@RequestParam("debitBalance") double balance,
			@RequestParam("accountNum") String accountNum,
			Model model)
	{
		System.out.println("In debitBalance() method");
		
		TransactionDTO transactionDTO=new TransactionDTO();
		transactionDTO.setTransDesc("ATM Debit");
		transactionDTO.setTransAmount(balance);
		transactionDTO.setAccountNum(accountNum);
		LocalDate dt=LocalDate.now();
		Date date=Date.valueOf(dt);
		transactionDTO.setDate(date);
		
		accountsRepository.insertTransactionDetails(transactionDTO);
		model.addAttribute("accountNum",accountNum);
		model.addAttribute("balance",balance);
		return "TransactionSuccess";
	}

}
