package com.cg.trainee.service;

import java.util.List;

import com.cg.trainee.entities.TraineeClient;

public interface ITraineeService {

	TraineeClient insert(TraineeClient trainee);

	List<TraineeClient> loadAll();

	TraineeClient getDetails(int traineeId);

	TraineeClient deleteTrainee(int traineeId);

	TraineeClient modify(TraineeClient trainee);
	

}
