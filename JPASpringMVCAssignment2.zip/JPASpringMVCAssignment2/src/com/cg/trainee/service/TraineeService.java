package com.cg.trainee.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.trainee.dao.ITraineeDao;
import com.cg.trainee.entities.TraineeClient;

@Service
public class TraineeService implements ITraineeService{
	
    @Autowired
	ITraineeDao traineeDao;
    
    
	@Override
	public TraineeClient insert(TraineeClient trainee)
	{
		return traineeDao.insert(trainee);
	}


	@Override
	public List<TraineeClient> loadAll() {
		// TODO Auto-generated method stub
		return traineeDao.loadAll();
	}


	@Override
	public TraineeClient getDetails(int traineeId) {
		// TODO Auto-generated method stub
		return traineeDao.getDetails(traineeId);
	}


	@Override
	public TraineeClient deleteTrainee(int traineeId) {
		// TODO Auto-generated method stub
		return traineeDao.deleteTrainee(traineeId);
	}


	@Override
	public TraineeClient modify(TraineeClient trainee) {
		// TODO Auto-generated method stub
		return traineeDao.modify(trainee);
	}
}