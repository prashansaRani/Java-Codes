package com.cg.trainee.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.trainee.entities.TraineeClient;
//@Component(value="dao")
@Repository
@Transactional
public class TraineeDao implements ITraineeDao{
	
	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public TraineeClient insert(TraineeClient trainee) {
		
		entityManager.persist(trainee);
		entityManager.flush();
		return trainee;
	}

	@Override
	public List<TraineeClient> loadAll() {
		// TODO Auto-generated method stub
		TypedQuery<TraineeClient> query = entityManager.createQuery("select t from TraineeClient t", TraineeClient.class);
		return query.getResultList();
	}

	@Override
	public TraineeClient getDetails(int traineeId) {
		// TODO Auto-generated method stub
		TypedQuery<TraineeClient> query = entityManager.createQuery("SELECT t FROM TraineeClient t WHERE t.traineeId="+traineeId,  TraineeClient.class);
		return query.getSingleResult();
	}
	
	@Override
	public TraineeClient modify(TraineeClient trainee) {
		trainee = entityManager.merge(trainee);
		entityManager.flush();	//required to reflect changes on database
		return trainee;
	}

	@Override
	public TraineeClient deleteTrainee(int traineeId) {
		// TODO Auto-generated method stub
		TraineeClient trainee = entityManager.find(TraineeClient.class, traineeId);
		entityManager.remove(trainee);
		return trainee;
	}

}
