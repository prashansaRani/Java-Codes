package com.cg.trainee.dao;

import java.util.List;

import com.cg.trainee.entities.TraineeClient;

public interface ITraineeDao {

	TraineeClient insert(TraineeClient trainee);

	List<TraineeClient> loadAll();

	TraineeClient getDetails(int traineeId);

	TraineeClient deleteTrainee(int traineeId);

	TraineeClient modify(TraineeClient trainee);

}
