package com.cg.trainee.entities;

public class LoginClient {

}
