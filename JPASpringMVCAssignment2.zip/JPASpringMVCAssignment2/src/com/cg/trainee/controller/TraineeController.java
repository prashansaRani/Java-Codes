package com.cg.trainee.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.trainee.entities.TraineeClient;
import com.cg.trainee.service.ITraineeService;

@Controller
public class TraineeController {
	@Autowired
	ITraineeService traineeService;	
	
	@RequestMapping("/login.htm")
	public String validation(@RequestParam("userName") String userName,@RequestParam("userPassword") String userPassword)
	{
		if(userName.equals("prashu") && userPassword.equalsIgnoreCase("prashu123"))
		{return "TraineeManagement";}
		else{return "Login";}	
	}
	
	@RequestMapping("/add.htm")
	public String add(ModelMap map)
	{
		map.addAttribute("trainee", new TraineeClient());
		return "Add";	
	}
	
	@RequestMapping(value ="/insert.htm",method= RequestMethod.POST)
	public String save(@ModelAttribute("trainee") TraineeClient trainee,Model model)
	{
		TraineeClient traineeCheck = traineeService.insert(trainee);
		model.addAttribute("message","Trainee with id "+trainee.getTraineeId()+" added successfully!");
		return "TraineeManagement";	
	}
	
	@RequestMapping("/delete.htm")
	public String delete()
	{
		return "Delete";
	}
	
	@RequestMapping("/getDTrainee.htm")
	public String getDetail(@RequestParam("traineeId") int traineeId, Model model)
	{
		TraineeClient trainee = traineeService.getDetails(traineeId);	
		model.addAttribute("trainee", trainee);
		return "Delete";
	}
	
	@RequestMapping("/deleteTrainee.htm")
	public String deleteTrainee(@RequestParam("traineeId") int traineeId, Model model)
	{
		TraineeClient trainee = traineeService.deleteTrainee(traineeId);
		String message = null;
		
		if(trainee == null){
			message = new String("Couldn't find trainee");
		}else{
			message = new String("Trainee deleted");
		}
		model.addAttribute("message",message);
		return "TraineeManagement";	
	}
	
	@RequestMapping(value="/modify.htm")
	public String modify()
	{
		return "Modify";
	}
	
	@RequestMapping("/modifyTrainee.htm")
	public String getNewTrainee(@RequestParam("traineeId") int traineeId, Model model){
	TraineeClient	trainee =  traineeService.getDetails(traineeId);
	model.addAttribute("trainee",trainee);
	return "Modify";
	}
	
	@RequestMapping(value="/update.htm")
	public String modifyTrainee(@RequestParam("traineeId")int traineeId, @RequestParam("traineeName") String traineeName, @RequestParam("traineeLocation") String traineeLocation, @RequestParam("traineeDomain") String traineeDomain, Model model){
		TraineeClient trainee =  new TraineeClient();
		trainee.setTraineeId(traineeId);
		trainee.setTraineeName(traineeName);
		trainee.setTraineeDomain(traineeDomain);
		trainee.setTraineeLocation(traineeLocation);

		trainee =  traineeService.modify(trainee);
		
		model.addAttribute("message","Trainee with id "+trainee.getTraineeId()+" modified successfully!");
		return "TraineeManagement";
	}
	
	
	
	@RequestMapping("/retrieve.htm")
	public String retrieveTrainee()
	{
		return "Retrieve";			
	}
	
	@RequestMapping("/getTrainee.htm")
	public String getATrainee(@RequestParam("traineeId") int traineeId, Model model)
	{
	TraineeClient trainee = traineeService.getDetails(traineeId);	
	model.addAttribute("trainee", trainee);
	return "Retrieve";	
	}
	
	@RequestMapping("/retrieveAll.htm")
	public String retrieveAll(Model model)
	{
		List<TraineeClient> traineeList = traineeService.loadAll();
		model.addAttribute("traineeList",traineeList);
		return "RetrieveAll";
	}
	
	
	
	

}
